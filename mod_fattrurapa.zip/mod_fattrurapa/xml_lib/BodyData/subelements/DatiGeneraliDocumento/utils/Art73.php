<?php
/**
 * Created by PhpStorm.
 * User: pado
 * Date: 08/12/18
 * Time: 18.11
 */

class Art73 {

    const documento_emesso_secondo_modalita_e_termini_stabiliti_con_DM_ai_sensi_del_art_73 = 'SI';

    public $type;
    public function __construct($type) {
        $this->type = $type;
    }
}