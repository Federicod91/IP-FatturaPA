<?php
/**
 * Created by PhpStorm.
 * User: pado
 * Date: 06/12/18
 * Time: 11.54
 */

class RegimeFiscaleClass {
    const Ordinario = "RF01";
    const Contribuenti_minimi = "RF02";
    const Agricoltura_e_attivita_connesse_e_pesca = "RF04";
    const Vendita_sali_e_tabacchi = "RF05";
    const Commercio_dei_fiammiferi = "RF06";
    const Editoria = "RF07";
    const Gestione_di_servizi_di_telefonia_pubblica = "RF08";
    const Rivendita_di_documenti_di_trasporto_pubblico_e_di_sosta = "RF09";
    const Intrattenimenti_giochi_e_altre_attivita_di_cui_alla_tariffa_allegata = "RF10";
    const Agenzie_di_viaggi_e_turismo = "RF11";
    const Agriturismo = "RF12";
    const Vendite_a_domicilio = "RF13";
    const Rivendita_di_beni_usati_di_oggetti_darte_dantiquariato_o_da_collezione = "RF14";
    const Agenzie_di_vendite_allasta_di_oggetti_darte_antiquariato_o_da_collezione = "RF15";
    const IVA_per_cassa_PA = "RF16";
    const IVA_per_cassa = "RF17";
    const Altro = "RF18";
    const Forfettario = "RF19";
}